package Assign;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import java.io.IOException;
import java.util.HashMap;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.Test;
import org.xml.sax.SAXException;
import Objects.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class JustPark {

	public static WebDriver driver;
	Utility utility;
	JustParkObjects obj;
	Xls_Reader excelfile;
	Logger logger = Logger.getLogger("JustPark");

	String fileName = "DataFile", SheetName = "Sheet1", location = "London", url = "";
	int counter = 0;

	@BeforeSuite
	public void preReq() throws InterruptedException, IOException, ParserConfigurationException, SAXException { 

		WebDriverManager.chromedriver().setup();
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		//		chromePrefs.put("download.default_directory", downloadPath);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);	
		options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		options.addArguments("chrome.switches", "--disable-extensions");
		options.setCapability(ChromeOptions.CAPABILITY, options);
		options.setExperimentalOption("useAutomationExtension", false);
		//				options.addArguments("--headless");
		driver= new ChromeDriver(options);
		PropertyConfigurator.configure("Log4j.properties");

		utility = new Utility();
		obj = new JustParkObjects(driver);
		url = utility.getURL();
		logger.info(url);
		// Launch the JustPark web application
		driver.get(url);
		//Maximize the browser
		driver.manage().window().maximize();
	}

	@Test(priority=1, dataProvider = "get_test_data")
	public void testSteps (String duration) throws InterruptedException{

		counter = Integer.parseInt(duration);
		//Launch JustPark
		driver.get(url);
		//Check if DOM is fully loaded
		utility.checkPageIsReady(driver);
		
		//Get and Print system date
		String todaysDate = utility.TodaysDate();
		System.out.println(todaysDate);
		
		//Click on Hourly/Daily tab
		utility.PomFindClick(driver, obj.hourlyDailySearchType);
		logger.info("Hourly search type selected");
		
		//Get "Location" textbox
		utility.PomFindField(driver, obj.searchBox, location);
		Thread.sleep(2000);
		
		//Wait until location is visible
		try {
			utility.Pause(driver, obj.searchResults, "Visibility", 20);
		}
		catch (Exception exc32) {}

		//Location is entered
		utility.PomFindField(driver, obj.searchBox, Keys.ENTER);
		logger.info("Location entered");

		// Enter Start Date
		utility.PomFindClick(driver, obj.bookingDates.get(0));

		// Enter End Date
		utility.PomFindClick(driver, obj.bookingDates.get(1));
		obj.enterEndDate(driver, duration);
		utility.PomFindClick(driver, obj.datePickerCloseBtn);
		
		//Click "Show Parking Spaces"
		utility.PomFindClick(driver, obj.submitForm);
		logger.info("Show parking spaces clicked");
		
		//Check user is in SRP
		utility.checkPageIsReady(driver);
		Thread.sleep(1000);
		String getUrl = driver.getCurrentUrl();
		Assert.assertTrue(getUrl.contains("search"), "Search result page not opened");

		/* If duration is less than 28 days check that modal is not appearing 
		and update the end date*/
		if (Integer.parseInt(duration) < 28) {
			try {
				utility.Pause(driver, obj.bookingDates.get(0), "Visibility", 10);
			} catch (Exception exc32) {}
			
			try {
				Assert.assertTrue(obj.modal.isDisplayed());
				Assert.fail();
			}
			catch (Exception ecx) {}
			
			try {
				Thread.sleep(1000);
				utility.PomFindClick(driver, obj.showOtherSpacesPopup);
			}
			catch (Exception ewzx) {}

			// Change the end date in SRP
			utility.PomFindClick(driver, obj.bookingDates.get(1));
			obj.enterEndDate(driver, Integer.toString(28));

			//Update search in SRP to greater than equal to 28 days
			utility.PomFindClick(driver, obj.submitForm);
			logger.info("Updated search performed in SRP");

			utility.checkPageIsReady(driver);
		}		
		
		//Wait for "Monthly Saver" modal to be visible
		try {
			utility.Pause(driver, obj.modal, "Visibility", 10);
		} catch (Exception exce23) {}
		
		//Assert if display conditions of "Monthly Saver" modal is as expected
		Assert.assertTrue(obj.modal.isDisplayed(), "Monthly upgrade modal is not displayed");

		//User clicks on "Switch to Monthly PArking"
		utility.PomFindClick(driver, obj.switchToMonthlyParking);
		logger.info("Switch to monthly parking clicked");

		Thread.sleep(2000);
		
		//Wait till "Duration" is visible
		try {
			utility.Pause(driver, obj.checkRollingDate, "Visibility", 10);
		} catch (Exception ecx43) {}
		
		//Get text from "Start On"
		String getDate = utility.PomReturnText(driver, obj.bookingStartDateOnSearchPage).trim();
		
		//Assert if Today is displayed on "Start On"
		Assert.assertTrue(getDate.contains("Today"));
		//Assert if "Rolling" is displayed on Duration
		Assert.assertTrue(obj.checkRollingDate.isDisplayed(), "Rolling duration is not displayed");

	}

	@AfterMethod
	public void onTestFaliure(ITestResult iTestResult){

		if(ITestResult.FAILURE==iTestResult.getStatus()){
			utility.captureScreenshot(driver,iTestResult.getName() + "_" + counter);
		}
	}

	@AfterSuite
	public void closeBrowser(){
		driver.quit();
	}

	//DATA INSERTION
	@org.testng.annotations.DataProvider
	public Object[][] get_test_data(){

		String filepath = System.getProperty("user.dir")+"\\"+fileName+".xlsx";

		if(excelfile == null){
			// load the Excel sheet
			excelfile = new Xls_Reader(filepath);		
		}

		int rows = excelfile.getRowCount(SheetName);  // Get Row Count
		int cols = excelfile.getColumnCount(SheetName);  // Get Column Count	

		Object data[][] = new Object[rows-1][cols]; //-1
		for(int rowNum = 2 ; rowNum <= rows ; rowNum++){ //2					
			for(int colNum=0 ; colNum < cols; colNum++){
				data[rowNum-2][colNum]=excelfile.getCellData(SheetName, colNum, rowNum);//-2
			}
		}
		return data;	
	}

}