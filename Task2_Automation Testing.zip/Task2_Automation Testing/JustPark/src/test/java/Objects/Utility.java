package Objects;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class Utility {

	public static WebDriverWait wait;
	WebElement element;
	Logger logger = Logger.getLogger("Utility");
	

	// This function will return Credentials in ArrayList from XML file.
	public String getURL() throws ParserConfigurationException, SAXException, IOException {
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();

		String filePath = System.getProperty("user.dir") + "\\Credentials\\Credentials.xml";

		Document document = builder.parse(new File(filePath));
		org.w3c.dom.Element rootElement = document.getDocumentElement();
		String URL = rootElement.getElementsByTagName("URL").item(0).getTextContent();

		return URL;
	}
	
	public void checkPageIsReady(WebDriver driver) {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		// Initially bellow given if condition will check ready state of page.
		if (js.executeScript("return document.readyState").toString().equals("complete")) {
			System.out.println("Page Is loaded.");

		}
		// This loop will rotate for 25 times to check If page Is ready after every 1
		// second.
		// You can replace your value with 25 If you wants to Increase or decrease wait
		// time.
		else {

			for (int i = 0; i < 25; i++) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				}
				// To check page ready state.
				if (js.executeScript("return document.readyState").toString().equals("complete")) {
					System.out.println("Page Is loaded.");
					break;
				}
			}
		}

	}


	// This function will wait for element according to time(seconds) and condition
	// (Visibility,Click and Frame)
	public static void Pause(WebDriver driver, WebElement element, String KeyWord, int timeInSeconds) {

		wait = new WebDriverWait(driver, timeInSeconds); // time to pause in seconds
		boolean result = false;
		int attempts = 0;
		while (attempts < 4) {

			try {
				// waiting for the element to be visible
				if (KeyWord.contains("Visibility")) {
					wait.until(ExpectedConditions.visibilityOf(element)); 

				} 
				// waiting for the element to be Clickable
				else if (KeyWord.contains("Click")) {
					wait.until(ExpectedConditions.elementToBeClickable(element)); 
				} 
				// waiting for the frame to be available and switch to it
				else if (KeyWord.contains("Frame")) {
					wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(element));
				}
				//Waiting for element to be invisible
				else if (KeyWord.contains("Invisibility")) {
					wait.until(ExpectedConditions.invisibilityOf(element));
				} 
				//Waiting for alert to be present
				else if (KeyWord.contains("Alert")) {
					wait.until(ExpectedConditions.alertIsPresent());
				}

				result = true;
				break;
			} catch (StaleElementReferenceException e) {

			}
			attempts++;
		}

	}
	//To click on element
	public static void PomFindClick(WebDriver driver, WebElement element) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 4) {
			try {
				element.click();
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}

	}

	//To find field and send keys via text
	public static void PomFindField(WebDriver driver, WebElement element, String text) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 4) {
			try {
				element.clear();
				element.sendKeys(text);
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}

	}
	//To find field and send keys via keyboard
	public static void PomFindField(WebDriver driver, WebElement element, Keys key) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 4) {
			try {
				element.sendKeys(key);
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}

	}

	//TO fetch a text
	public static String PomReturnText(WebDriver driver, WebElement element) {
		boolean result = false;
		String val1 = "";
		int attempts = 0;
		while (attempts < 2) {
			try {
				val1 = element.getText();
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;
		}
		return val1;
	}

	// ------------------------- End of POM Functions ---------------------- //

	// This function will return the Todays Date.
	public static String TodaysDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar date1 = Calendar.getInstance();
		Date currentDate = date1.getTime();
		String CurrentDate = dateFormat.format(currentDate).toString();
		return CurrentDate;

	}
	
	// This function will capture screenshot
	
	public static void captureScreenshot(WebDriver driver, String screenshotName) {

		try {
			TakesScreenshot ts = (TakesScreenshot) driver;

			File source = ts.getScreenshotAs(OutputType.FILE);

			FileUtils.copyFile(source, new File("./Screenshots/" + screenshotName + ".png"));

			System.out.println("Screenshot taken");
		} catch (Exception e) {

			System.out.println("Exception while taking screenshot " + e.getMessage());
		}
	}
}