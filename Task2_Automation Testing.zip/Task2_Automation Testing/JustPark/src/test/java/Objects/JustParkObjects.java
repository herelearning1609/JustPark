package Objects;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import freemarker.log.Logger;

public class JustParkObjects {

	WebDriver driver;
	Utility utility;
	Logger logger = Logger.getLogger("JustParkObjects");
	
	@FindBy(xpath = "//*[contains(text(), 'Hourly / Daily')]")
	public WebElement hourlyDailySearchType;
	
	@FindBy(id = "search-box")
	public WebElement searchBox;
	
	@FindBy(xpath = "//*[@class='c-predictive-search-input__results-container']")
	public WebElement searchResults;
	
	@FindBy(xpath = "//*[contains(@class, 'c-booking-date__date-display')]")
	public List<WebElement> bookingDates;
	
	@FindBy(xpath = "//*[contains(@class, 'c-searchform__submit')]")
	public WebElement submitForm;
	
	@FindBy(xpath = "//*[contains(@class, 'monthlyUpgradeModal')]")
	public WebElement modal;
	
	@FindBy(xpath = "//span[contains(text(), 'Switch to monthly parking')]")
	public WebElement switchToMonthlyParking;
	
	@FindBy(xpath = "//span[contains(@class, 'c-booking-date__date-display')]")
	public WebElement bookingStartDateOnSearchPage;
	
	@FindBy(xpath = "//*[@class='c-long-term-duration-picker']//*[contains(text(), 'Rolling')]")
	public WebElement checkRollingDate;
	
	@FindBy(xpath = "//*[contains(@aria-label, 'next month')]")
	public WebElement nextMonthButton;
	
	@FindBy(xpath = "//*[@data-cy='datepicker-close-button']")
	public WebElement datePickerCloseBtn;
	
	public WebElement getDate (String date) {
		return driver.findElement(By.xpath("//*[contains(@class, 'CalendarMonth') and @data-visible = 'true']//*[contains(@class, 'CalendarDay') and @aria-disabled = 'false' and text() = '"+date+"']"));
	}
	
	@FindBy(xpath = "//*[text()='Show other spaces']")
	public WebElement showOtherSpacesPopup;
	
	public void enterEndDate(WebDriver driver, String duration) throws InterruptedException {
		
		Thread.sleep(3000);
		
		String todaysDate = utility.TodaysDate(); // 06/06/2022
		int date = Integer.parseInt(todaysDate.split("/")[0]), 
				monthsToAdd = 0;
		int finalDate = date + Integer.parseInt(duration);
		
		if (finalDate > 30 && finalDate < 61) {
			monthsToAdd = 1;
		}
		else if (finalDate > 62) {
			monthsToAdd = 2;
		}
		
		// Check for next month date
		for (int i=0; i<monthsToAdd; i++) {
			utility.PomFindClick(driver, nextMonthButton);
		}
		
		Thread.sleep(1000);
		
		// Select date
		int dateToAdd = finalDate % 30;
		if (dateToAdd == 0) {
			dateToAdd = 1;
		}
		utility.PomFindClick(driver, getDate(Integer.toString(dateToAdd)));
		
	}
	
	public JustParkObjects(WebDriver driver) {

		this.driver = driver;

		// This initElements method will create all WebElements

		PageFactory.initElements(driver, this);
		utility = new Utility();

	}
}
